globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/d403045ae342138f.js",
      "static/chunks/turbopack-704a09430cf6a21c.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/d403045ae342138f.js",
      "static/chunks/turbopack-acbb4c92cd320bd7.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/af565aa9e0364985.js",
    "static/chunks/34c4658583b69a91.js",
    "static/chunks/ff42156ceacb9fd8.js",
    "static/chunks/turbopack-ddcb6384b608cc11.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];