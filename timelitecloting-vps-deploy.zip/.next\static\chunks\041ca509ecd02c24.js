__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/d403045ae342138f.js",
  "static/chunks/turbopack-704a09430cf6a21c.js"
])
